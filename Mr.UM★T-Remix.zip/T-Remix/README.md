
### What is T-Remix??
T-Remix or Tremix will Help to Customise Your Termux in such a way that you will Enjoy using Termux it will give you a morden look and we also have add a feature of password,so now you can also set Password on your Termux and protect it so no one can login in your termux in absence of you.
one more feature that we have added is that you can change dollar sign and put anything you want in that place.
Hope you guys like this Project,then dont forget to give it a like.
### Features of T-Remix
   1. Fully customise your Termux app.
   2. Encrypt your Termux app.
   3. Password protection.
   4. Welcome voice-message.
   5. Change the $ (DOLLAR) sign with a modern look.
   6. New banner.
   7. Login banner is for HACKERs only.
   8. Show off to other with hacker attitude.
# Developer's Image   
<img src="https://avatars3.githubusercontent.com/u/67367001?s=460&u=a3584dda8e1795eb39f9670ca8197c120d2cc497&v=4">
   
### WANNA TRY THIS NEW CUSTOMISATION OF TERMUX? IT'LL GIVE A MODERN LOOK TO YOUR TERMUX TO SHOW OFF :)
### Installation T-Remix
* `Commands` for termux
```
$ termux-setup-storage
  
$ pkg update && pkg upgrade && pkg install git -y

$ git clone https://github.com/Arij-arman/T-Remix

$ ls

$ cd T-Remix

$ ls

$ chmod +x *

$ bash t-remix.sh
```



### To Remove Banner
* `Commands` for termux
```
$ cd T-Remix

$ ls

$ bash remove-banner.sh
```
### To Remove Login
* `Commands` for termux
```
$ cd T-Remix

$ ls

$ bash remove-login.sh
```
### Development by ARIJ ARMAN
### Keep connected for hacking tools, Thank you.
### Subscribe my channel for hacking tutorials, <a href="https://www.youtube.com/channel/UCJ5H4A3QAsIbQsVqfMBdZYQ" target=_blank >Tech Know Linux </a>

